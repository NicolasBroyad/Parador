# Parador
https://prod.liveshare.vsengsaas.visualstudio.com/join?D7B37CDB77D686173CE98DF01756C07BF72F

PAGINAS DE REFERENCIA:
1-http://elsapofutbol.com/
2-https://torneoslacaprichosa.com.ar/?gclid=EAIaIQobChMIppPZppiZ-gIVQuVcCh34fA6aEAMYAiAAEgLdbvD_BwE
3-https://www.camptioga.com/summer-camp/program-activities/athletics-fitness/
4-
5-

PALETA: https://coolors.co/palette/121619-2d4739-09814a-bcb382-e5c687


